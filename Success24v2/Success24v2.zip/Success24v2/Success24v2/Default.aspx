﻿<%@ Page Title="" Language="C#" MasterPageFile="~/24.Master" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="Success24v2.Default" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
     <title>Mahesham Lodge - Room in Rent - HAJIPUR</title>
    <style type="text/css">
        .bg-breadcrumb {
            background: linear-gradient(rgba(242, 139, 0, 0.2), rgba(242, 139, 0, 0.3)), url(img/iq-india1.jpg) !important;
        }

        .counter-facts {
            background: linear-gradient(rgba(255, 255, 255, .8), rgba(255, 255, 255, 0.7)), url(img/iq-india3.jpg);
        }

        .img-fluid1 {
        }

        .w-80 {
        }

        .iheader img {
            object-fit: fill !important;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
     <asp:Literal runat="server" ID="_LiteralContent"></asp:Literal>
  
    <div class="header-carousel owl-carousel">

        <div class="header-carousel-item iheader">
            <img src="img/pooja2.jpeg" class="img-fluid w-80" alt="Image">
            <div class="carousel-caption">
                <div class="carousel-caption-content p-3" style="max-width: 900px;">
                    <h4 class="text-secondary text-uppercase sub-title fw-bold mb-4" style="letter-spacing: 3px;">सफलता के लिए एक कदम</h4>
                    <h1 class="display-1 text-capitalize text-white mb-4">कौशल भारत कुशल भारत</h1>
                    <p class="fs-5">
                        आपकी बड़ी सफलता के लिए एक कदम। शून्य निवेश और सफलता साझा मॉडल। कौन कहता है कि बिना पैसे के आप सफल नहीं होंगे। सफलता के लिए केवल जुनून की आवश्यकता होती है। औसत वेतन नौ से दस लाख।
                    </p>                  
                </div>
            </div>
        </div>
        <div class="header-carousel-item">
            <img src="img/iq-india3.jpg" class="img-fluid w-100" alt="Image">
            <div class="carousel-caption">
                <div class="carousel-caption-content p-3" style="max-width: 900px;">
                    <h4 class="text-secondary text-uppercase sub-title fw-bold mb-4 wow fadeInUp" data-wow-delay="0.1s" style="letter-spacing: 3px;">Let's navigate success together</h4>
                    <h1 class="display-1 text-capitalize text-white mb-4 wow fadeInUp" data-wow-delay="0.3s">Once A Professional, Is Always A Success</h1>
                    <p class="fs-5 wow fadeInUp" data-wow-delay="0.5s">
                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
                    </p>                  
                </div>
            </div>
        </div>
        <div class="header-carousel-item">
            <img src="img/iq-india1.jpg" class="img-fluid1 w-1001" alt="Image">
            <div class="carousel-caption">
                <div class="carousel-caption-content p-3" style="max-width: 900px;">
                    <h4 class="text-secondary text-uppercase sub-title fw-bold mb-4" style="letter-spacing: 3px;">Let's Dance</h4>
                    <h1 class="display-1 text-capitalize text-white mb-4">Once A Dancer, Is Always A Dance</h1>
                    <p class="fs-5">
                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
                    </p>                   
                </div>
            </div>
        </div>
      
    </div>


    <div class="container-fluid counter-facts py-5">
        <div class="container">
            <div class="row">
                <div class="col-12 col-sm-6 col-md-6 col-xl-3 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="counter">
                        <div class="counter-icon w-100 d-flex align-items-center justify-content-center">
                            <h3>Total Success</h3>
                        </div>
                        <div class="counter-content d-flex align-items-center justify-content-center mt-4">
                            <span class="counter-value" data-toggle="counter-up">
                                <asp:Literal runat="server" ID="_LiteralSuccess"></asp:Literal></span>
                            <h4 class="text-secondary mb-0" style="font-weight: 600; font-size: 25px;">+</h4>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-6 col-xl-3 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="counter">
                        <div class="counter-icon w-100 d-flex align-items-center justify-content-center">
                            <h3>Best Instructor</h3>
                        </div>
                        <div class="counter-content d-flex align-items-center justify-content-center mt-4">
                            <span class="counter-value" data-toggle="counter-up">10</span>
                            <h4 class="text-secondary mb-0" style="font-weight: 600; font-size: 25px;">+</h4>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-6 col-xl-3 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="counter">
                        <div class="counter-icon w-100 d-flex align-items-center justify-content-center">
                            <h3>Total Brunch</h3>
                        </div>
                        <div class="counter-content d-flex align-items-center justify-content-center mt-4">
                            <span class="counter-value" data-toggle="counter-up">
                                <asp:Literal runat="server" ID="_LiteralBatch"></asp:Literal></span>
                            <h4 class="text-secondary mb-0" style="font-weight: 600; font-size: 25px;">+</h4>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-6 col-xl-3 wow fadeInUp" data-wow-delay="0.7s">
                    <div class="counter">
                        <div class="counter-icon w-100 d-flex align-items-center justify-content-center">
                            <h3>Total Practitioner</h3>
                        </div>
                        <div class="counter-content d-flex align-items-center justify-content-center mt-4">
                            <span class="counter-value" data-toggle="counter-up">
                                <asp:Literal runat="server" ID="_LiteralPrac"></asp:Literal></span>
                            <h4 class="text-secondary mb-0" style="font-weight: 600; font-size: 25px;">+</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <div class="container-fluid events py-5">
        <div class="container py-5">
            <div class="pb-5">
                <div class="row g-4 align-items-end">
                    <div class="col-xl-8">
                        <h4 class="text-secondary sub-title fw-bold wow fadeInUp" data-wow-delay="0.1s">Programs</h4>
                        <h1 class="display-2 mb-0 wow fadeInUp" data-wow-delay="0.3s">Upcoming Programs</h1>
                    </div>
                    <div class="col-xl-4 text-xl-end pb-3 wow fadeInUp" data-wow-delay="0.3s">
                        <a class="btn btn-primary rounded-pill text-white py-3 px-5" href="#">View All Programs</a>
                    </div>
                </div>
            </div>
            <div class="row g-4 justify-content-center">
                <div class="col-md-6 col-lg-4 col-xl-3 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="event-item rounded">
                        <div class="position-relative">
                            <img src="img/ds.jpg" class="img-fluid rounded-top w-100" alt="Image">
                            <div class="bg-primary text-white fw-bold rounded d-inline-block position-absolute p-2" style="top: 0; right: 0;">JUN 28</div>
                            <div class="d-flex justify-content-between border-start border-end bg-white px-2 py-2 w-100 position-absolute" style="bottom: 0; left: 0; opacity: 0.8;">
                                <a href="#" class="text-dark"><i class="fas fa-chair text-primary"></i>24</a>
                                <a href="#" class="text-dark"><span class="fas fa-map-marker-alt text-primary"></span>New Delhi</a>
                            </div>
                        </div>
                        <div class="border border-top-0 rounded-bottom p-4">
                            <a href="#" class="h4 mb-3 d-block">Data Science Engineering</a>
                            <p class="mb-3">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Magni vero excepturi blanditiis quidem</p>
                            <a class="btn btn-primary rounded-pill text-white py-2 px-4" href="#">Register Now</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="event-item rounded">
                        <div class="position-relative">
                            <img src="img/devops.jpeg" class="img-fluid rounded-top w-100" alt="Image">
                            <div class="bg-primary text-white rounded d-inline-block position-absolute p-2" style="top: 0; right: 0;">JUN 30</div>
                            <div class="d-flex justify-content-between border-start border-end bg-white px-2 py-2 w-100 position-absolute" style="bottom: 0; left: 0; opacity: 0.8;">
                                <a href="#" class="text-dark"><i class="fas fa-chair text-primary"></i>24</a>
                                <a href="#" class="text-dark"><span class="fas fa-map-marker-alt text-primary"></span>New Delhi</a>
                            </div>
                        </div>
                        <div class="border rounded-bottom p-4">
                            <a href="#" class="h4 mb-3 d-block">DevOps Engineering</a>
                            <p class="mb-3">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Magni vero excepturi blanditiis quidem</p>
                            <a class="btn btn-primary rounded-pill text-white py-2 px-4" href="#">Register Now</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="event-item rounded">
                        <div class="position-relative">
                            <img src="img/sp.jpg" class="img-fluid rounded-top w-100" alt="Image">
                            <div class="bg-primary text-white rounded d-inline-block position-absolute p-2" style="top: 0; right: 0;">MAY 15</div>
                            <div class="d-flex justify-content-between border-start border-end bg-white px-2 py-2 w-100 position-absolute" style="bottom: 0; left: 0; opacity: 0.8;">
                                <a href="#" class="text-dark"><i class="fas fa-chair text-primary"></i>24</a>
                                <a href="#" class="text-dark"><span class="fas fa-map-marker-alt text-primary"></span>New Delhi</a>
                            </div>
                        </div>
                        <div class="border rounded-bottom p-4">
                            <a href="#" class="h4 mb-3 d-block">SharePoint Development Engineering</a>
                            <p class="mb-3">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Magni vero excepturi blanditiis quidem</p>
                            <a class="btn btn-primary rounded-pill text-white py-2 px-4" href="#">Register Now</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3 wow fadeInUp" data-wow-delay="0.7s">
                    <div class="event-item rounded">
                        <div class="position-relative">
                            <img src="img/sdet.jpg" class="img-fluid rounded-top w-100" alt="Image">
                            <div class="bg-primary text-white rounded d-inline-block position-absolute p-2" style="top: 0; right: 0;">APR 2</div>
                            <div class="d-flex justify-content-between border-start border-end bg-white px-2 py-2 w-100 position-absolute" style="bottom: 0; left: 0; opacity: 0.8;">
                                <a href="#" class="text-dark"><i class="fas fa-chair text-primary"></i>24</a>
                                <a href="#" class="text-dark"><span class="fas fa-map-marker-alt text-primary"></span>New Delhi</a>
                            </div>
                        </div>
                        <div class="border rounded-bottom p-4">
                            <a href="#" class="h4 mb-3 d-block">Software Development Engineer in Test</a>
                            <p class="mb-3">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Magni vero excepturi blanditiis quidem</p>
                            <a class="btn btn-primary rounded-pill text-white py-2 px-4" href="#">Register Now</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


</asp:Content>
